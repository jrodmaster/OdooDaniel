# -*- coding: utf-8 -*-
# © 2019 Santrech ORP, SRL (Daniel Diaz <ddiaz@cs.com.do>)
# License AGPL-3.0 or later (http://www.gnu.org/licenses/agpl).

from odoo import models, fields, api, _


class ApiServer(models.Model):
    _name = "api.server"

    name = fields.Char(string='Api Server Name', required=True)
    active = fields.Boolean(string='Active', default=True)
    url = fields.Char(string='Url', placeholder="Especificar la URL de conexion para devolver el valor deseado.", required=True)
# -*- coding: utf-8 -*-
import requests

from odoo import fields, models, api, _
# import tools
from odoo import exceptions

import logging

_logger = logging.getLogger(__name__)

try:
    from stdnum.do import ncf
except(ImportError, IOError) as err:
    _logger.debug(err)

try:
    from stdnum.do import ncf
except(ImportError, IOError) as err:
    _logger.debug(err)


class SantrechApiTools(models.Model):
    _name = 'santrech.api.tools'
#
#     def is_identification(self, value):
#         return tools.is_identification(value)
#
#     def is_ncf(self, value, type):
#         return tools.is_ncf(value, type)
#
    @api.model
    def setup(self):
        api_santrech = ''
        config_parameter = self.env['api.server'].search([])
        for config in config_parameter:
            if config.active:
                # config.create({"url": "http://www.santrech.com/consult/search.php?rnc="})
                api_santrech = config.url
                return api_santrech
        if not api_santrech:
            raise exceptions.except_orm(_('Advertencia'), _(
                'No se ha encontrado al menos una configuracion de Api por favor proceda a crearlo.'))

    def get_santrech_api_request_params(self):

        api_santrech = self.setup()

        if not api_santrech:
            raise exceptions.ValidationError(
                u"Debe configurar la URL de validación en línea: es la variable api_santrech en el menu de parametros del sistema, situado en configuracion")
        #if not tools._internet_on(api_santrech):
        #    return exceptions.ValidationError(u"No se pudo validar con la DGII por falta de conexión a internet.")

        return (1, api_santrech)


class ResPartner(models.Model):
    _inherit = 'res.partner'

    sale_fiscal_type_santrech = fields.Selection(
        [("final", "Consumo"),
         ("fiscal", u"Crédito Fiscal"),
         ("gov", "Gubernamental"),
         ("special", u"Regímenes Especiales"),
         ("unico", u"Único Ingreso")],
        string="Tipo de comprobante", default="final")

    @api.onchange("name")
    def onchange_partner(self):
        message = u"El contacto: %s, esta registrado con este RNC/Céd."
        exist = self.search([('vat', '=', str(self.name))])
        if exist:
            raise exceptions.Warning(_(message % exist.name))
            # raise UserError(_(message % exist.name))
        if self.name and (len(self.name) == 9 or len(self.name) == 11):
            result = self.rnc_cedula_validation(self.name)
            if result:
                self.name = result[1]['name']
                self.vat = result[1]['vat']
                self.street = result[1]['street']
                self.street2 = result[1]['street2']
                self.trust = result[1]['trust']
                self.phone = result[1]['phone']
                self.function = result[1]['function']
                self.country_id = result[1]['country_id']
                self.company_type = 'person' # result[1]['company_type']
                self.sale_fiscal_type = result[1]['sale_fiscal_type']

    def rnc_cedula_validation(self, fiscal_id):
        invalid_fiscal_id_message = (500, u"RNC/Cédula invalido", u"El número de RNC/C´ula no es valido.")
        #if not tools.is_identification(fiscal_id):
        #    return invalid_fiscal_id_message
        #else:
        request_params = self.env['santrech.api.tools'].get_santrech_api_request_params()
        if request_params[0] == 1:
            res = requests.get('{}{}'.format(request_params[1], fiscal_id))
            if res.status_code == 200:
                dgii_data = res.json()
                dgii_data["vat"] = dgii_data['rnc_cedula']
                dgii_data["street"] = u"{} {} ".format(dgii_data['direccion'], dgii_data['numero'])
                dgii_data["street2"] = dgii_data['sector']
                dgii_data["country_id"] = 61
                dgii_data["phone"] = dgii_data['telefono']
                dgii_data["function"] = dgii_data['actividad_economica']
                dgii_data["name"] = dgii_data['razon_social']
                dgii_data["sale_fiscal_type"] = 'fiscal'
                if dgii_data['regimen_pago'] == 'NORMAL':
                    dgii_data["trust"] = 'normal'
                else:
                    dgii_data["trust"] = 'bad'
                if len(fiscal_id) == 9:
                    dgii_data["company_type"] = 'company'
                else:
                    dgii_data["company_type"] = 'person'
                return (1, dgii_data)
            else:
                return invalid_fiscal_id_message

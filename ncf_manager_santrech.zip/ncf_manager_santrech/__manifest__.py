# -*- coding: utf-8 -*-
# © 2019 Santrech ORP, SRL (Daniel Diaz <daniel.diaz@santrech.com>)
# License AGPL-3.0 or later (http://www.gnu.org/licenses/agpl).

{
    'name': 'Buscar Partner Base de Datos Santrech/DGII',
    'version': '11.0',
    'category': 'search',
    'license': 'AGPL-3',
    'summary': "Buscar Partner Asociaciados al Regimen Contributivo",
    'description': """
Buscar y Crear Partner Asociaciados al Regimen Contributivo de la Republica Dominicana DGII.
==========================
 * Funcion Principal Buscar Partners.


Para contacto daniel.diaz@santrech.com

""",
    'author': "Santrech ORP, SRL, Odoo Community Association (OCA) Create by Daniel Diaz",
    'website': 'http://www.santrech.com/',
    'depends': ['base', 'account_accountant'],
    'data': [
        'view/api_server.xml',
        'security/ir.model.access.csv'
        ],
    'demo': [
    ],
    'qweb': [],
    'css': [],
    'application': True,
    'installable': True,
}